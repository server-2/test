<template>
    <div class="table-reponsive box">
        <table id="example" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>İsim</th>
                        <th>Soyisim</th>
                        <th>Devamsizlik</th>

                    </tr>
                </thead>
                <tbody v-for="ogrenci in ogrenciler" :key="ogrenci.no">
                    <tr >
                        <td>{{ ogrenci.no }}</td>
                        <td>{{ ogrenci.isim }}</td>
                        <td>{{ ogrenci.soyisim }}</td>
                        <td>{{ ogrenci.devamsizlik }}</td>
                      </tr>
                    
                </tbody>
            </table>
        </div>
  </template>
  
  <script>
  
  export default {
    data() {
      return {
        ogrenciler: [
          {
            no: '1001',
            isim: 'Ahmet',
            soyisim: 'Yılmaz',
            devamsizlik: 3,
          },
          {
            no: '1002',
            isim: 'Mehmet',
            soyisim: 'Demir',
            devamsizlik: 5,
          },
          {
            no: '1003',
            isim: 'Ayşe',
            soyisim: 'Kara',
            devamsizlik: 2,
          },
          {
            no: '1004',
            isim: 'Fatma',
            soyisim: 'Kılıç',
            devamsizlik: 0,
          },
          {
            no: '1002',
            isim: 'Mehmet',
            soyisim: 'Demir',
            devamsizlik: 5,
          },
          {
            no: '1003',
            isim: 'Ayşe',
            soyisim: 'Kara',
            devamsizlik: 2,
          },
          {
            no: '1004',
            isim: 'Fatma',
            soyisim: 'Kılıç',
            devamsizlik: 0,
          },
          {
            no: '1002',
            isim: 'Mehmet',
            soyisim: 'Demir',
            devamsizlik: 5,
          },
          {
            no: '1003',
            isim: 'Ayşe',
            soyisim: 'Kara',
            devamsizlik: 2,
          },
          {
            no: '1004',
            isim: 'Fatma',
            soyisim: 'Kılıç',
            devamsizlik: 0,
          },
          {
            no: '1002',
            isim: 'Mehmet',
            soyisim: 'Demir',
            devamsizlik: 5,
          },
          {
            no: '1003',
            isim: 'Ayşe',
            soyisim: 'Kara',
            devamsizlik: 2,
          },
          {
            no: '1004',
            isim: 'Fatma',
            soyisim: 'Kılıç',
            devamsizlik: 0,
          },
          {
            no: '1002',
            isim: 'Mehmet',
            soyisim: 'Demir',
            devamsizlik: 5,
          },
          {
            no: '1003',
            isim: 'Ayşe',
            soyisim: 'Kara',
            devamsizlik: 2,
          },
          {
            no: '1004',
            isim: 'Fatma',
            soyisim: 'Kılıç',
            devamsizlik: 0,
          },
        ],
      };
    },
  };
  </script>
  
  <style>
  table { 
	width: 750px; 
	border-collapse: collapse; 
	margin:50px auto;
	}

/* Zebra striping */
tr:nth-of-type(odd) { 
	background: #eee; 
	}

th { 
	background: #3498db; 
	color: white; 
	font-weight: bold; 
	}

td, th { 
	padding: 10px; 
	border: 1px solid #ccc; 
	text-align: left; 
	font-size: 18px;
	}

/* 
Max width before this PARTICULAR table gets nasty
This query will take effect for any screen smaller than 760px
and also iPads specifically.
*/
@media 
only screen and (max-width: 760px),
(min-device-width: 768px) and (max-device-width: 1024px)  {

	table { 
	  	width: 100%; 
	}

	/* Force table to not be like tables anymore */
	table, thead, tbody, th, td, tr { 
		display: block; 
	}
	
	/* Hide table headers (but not display: none;, for accessibility) */
	thead tr { 
		position: absolute;
		top: -9999px;
		left: -9999px;
	}
    
	tr { border: 1px solid #ccc; }
	
	td { 
		/* Behave  like a "row" */
		border: none;
		border-bottom: 1px solid #eee; 
		position: relative;
		padding-left: 50%; 
	}

	td:before { 
		/* Now like a table header */
		position: absolute;
		/* Top/left values mimic padding */
		top: 6px;
		left: 6px;
		width: 45%; 
		padding-right: 10px; 
		white-space: nowrap;
		/* Label the data */
		content: attr(data-column);

		color: #000;
		font-weight: bold;
	}

}
  </style>
  