<template>
    <div>
        <table>
        <thead>
          <tr>
            <th>Ders Adı</th>
            <th>Açıklama</th>
            <th>Ders Saati</th>
            <th>PDF</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(ders, index) in dersler" :key="index">
            <td>{{ ders.ad }}</td>
            <td>{{ ders.aciklama }}</td>
            <td>{{ ders.saat }}</td>
            <td>
              <a :href="ders.pdf" download>
                {{ ders.pdfName }}
              </a>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        dersler: [
          {
            ad: "Matematik",
            aciklama: "Matematik dersi",
            saat: "Pazartesi 09:00-10:00",
            pdf: "/pdf/matematik.pdf",
            pdfName: "Matematik Ders Notları",
          },
          {
            ad: "Fizik",
            aciklama: "Fizik dersi",
            saat: "Çarşamba 14:00-15:00",
            pdf: "/pdf/fizik.pdf",
            pdfName: "Fizik Ders Notları",
          },
          {
            ad: "Biyoloji",
            aciklama: "Biyoloji dersi",
            saat: "Perşembe 11:00-12:00",
            pdf: "/pdf/biyoloji.pdf",
            pdfName: "Biyoloji Ders Notları",
          },
          {
            ad: "Matematik",
            aciklama: "Matematik dersi",
            saat: "Pazartesi 09:00-10:00",
            pdf: "/pdf/matematik.pdf",
            pdfName: "Matematik Ders Notları",
          },
          {
            ad: "Fizik",
            aciklama: "Fizik dersi",
            saat: "Çarşamba 14:00-15:00",
            pdf: "/pdf/fizik.pdf",
            pdfName: "Fizik Ders Notları",
          },
          {
            ad: "Biyoloji",
            aciklama: "Biyoloji dersi",
            saat: "Perşembe 11:00-12:00",
            pdf: "/pdf/biyoloji.pdf",
            pdfName: "Biyoloji Ders Notları",
          },
          {
            ad: "Matematik",
            aciklama: "Matematik dersi",
            saat: "Pazartesi 09:00-10:00",
            pdf: "/pdf/matematik.pdf",
            pdfName: "Matematik Ders Notları",
          },
          {
            ad: "Fizik",
            aciklama: "Fizik dersi",
            saat: "Çarşamba 14:00-15:00",
            pdf: "/pdf/fizik.pdf",
            pdfName: "Fizik Ders Notları",
          },
          {
            ad: "Biyoloji",
            aciklama: "Biyoloji dersi",
            saat: "Perşembe 11:00-12:00",
            pdf: "/pdf/biyoloji.pdf",
            pdfName: "Biyoloji Ders Notları",
          },
          {
            ad: "Matematik",
            aciklama: "Matematik dersi",
            saat: "Pazartesi 09:00-10:00",
            pdf: "/pdf/matematik.pdf",
            pdfName: "Matematik Ders Notları",
          },
          {
            ad: "Fizik",
            aciklama: "Fizik dersi",
            saat: "Çarşamba 14:00-15:00",
            pdf: "/pdf/fizik.pdf",
            pdfName: "Fizik Ders Notları",
          },
          {
            ad: "Biyoloji",
            aciklama: "Biyoloji dersi",
            saat: "Perşembe 11:00-12:00",
            pdf: "/pdf/biyoloji.pdf",
            pdfName: "Biyoloji Ders Notları",
          },
          {
            ad: "Matematik",
            aciklama: "Matematik dersi",
            saat: "Pazartesi 09:00-10:00",
            pdf: "/pdf/matematik.pdf",
            pdfName: "Matematik Ders Notları",
          },
          {
            ad: "Fizik",
            aciklama: "Fizik dersi",
            saat: "Çarşamba 14:00-15:00",
            pdf: "/pdf/fizik.pdf",
            pdfName: "Fizik Ders Notları",
          },
          {
            ad: "Biyoloji",
            aciklama: "Biyoloji dersi",
            saat: "Perşembe 11:00-12:00",
            pdf: "/pdf/biyoloji.pdf",
            pdfName: "Biyoloji Ders Notları",
          },
        ],
      };
    },
  };
  </script>
  
  <style>
  table {
    border-collapse: collapse;
    width: 100%;
  }
  
  th,
  td {
    border: 1px solid black;
    padding: 8px;
    text-align: left;
  }
  
  th {
    background-color: #dddddd;
  }
  </style>
  