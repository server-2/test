<template>
    <div class="register">
        <form @submit.prevent="register">
        <div class="form-control">
          <label for="name">Öğrenci No:</label>
          <input type="text" id="no" v-model="no" required>
        </div>
        <div class="form-control">
          <label for="email">Ad:</label>
          <input type="email" id="ad" v-model="ad" required>
        </div>
        <div class="form-control">
          <label for="password">Soyad:</label>
          <input type="password" id="soyad" v-model="soyad" required>
        </div>
        
        <button type="submit">Ekle</button>
      </form>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        no: '',
        ad: '',
        soyad: '',
      }
    },
    methods: {
      register() {
        // Kayıt işlemini gerçekleştir
        console.log('Kayıt işlemi gerçekleştirildi.')
      }
    }
  }
  </script>
  
  <style scoped>
  .register {
    margin-top: 100px;
    margin-left: 500px;
    max-width: 400px;
    padding: 20px;
    border-radius: 5px;
    background-color: #f9f9f9;
    box-shadow: 0 0 10px #ccc;
    
  }
  
  h2 {
    
    margin-bottom: 20px;
  }
  
  form {
    display: flex;
    flex-direction: column;
  }
  
  .form-control {
    margin-bottom: 10px;
  }
  
  label {
    
    font-weight: bold;
    margin-bottom: 5px;
  }
  
  input {
    padding: 10px;
    border-radius: 5px;
    border: none;
    float: right;
    box-shadow: 0 0 5px #ccc;
    font-size: 16px;
    
  }
  
  button[type="submit"] {
    padding: 10px;
    border-radius: 5px;
    border: none;
    background-color: #007bff;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.3s ease;
  }
  
  button[type="submit"]:hover {
    background-color: #555;
  }
  </style>
  