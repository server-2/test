<template>
    <div>
        <form @submit.prevent="submit">
        <table>
          <thead>
            <tr>
              <th>Öğrenci No</th>
              <th>İsim</th>
              <th>Soyisim</th>
              <th>Devamsızlık</th>
              <th>Yoklama</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(ogrenci, index) in ogrenciler" :key="ogrenci.no">
              <td>{{ ogrenci.no }}</td>
              <td>{{ ogrenci.isim }}</td>
              <td>{{ ogrenci.soyisim }}</td>
              <td>{{ ogrenci.devamsizlik }}</td>
              <td>
                <input type="checkbox" :id="index" v-model="ogrenci.yoklama" />
                <label :for="index">Geldi</label>
              </td>
            </tr>
          </tbody>
        </table>
        <button type="submit">Yoklama Al</button>
      </form>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        ogrenciler: [
          {
            no: '1001',
            isim: 'Ahmet',
            soyisim: 'Yılmaz',
            devamsizlik: 3,
            yoklama: false,
          },
          {
            no: '1002',
            isim: 'Mehmet',
            soyisim: 'Demir',
            devamsizlik: 5,
            yoklama: false,
          },
          {
            no: '1003',
            isim: 'Ayşe',
            soyisim: 'Kara',
            devamsizlik: 2,
            yoklama: false,
          },
          {
            no: '1004',
            isim: 'Fatma',
            soyisim: 'Kılıç',
            devamsizlik: 0,
            yoklama: false,
          },
          {
            no: '1003',
            isim: 'Ayşe',
            soyisim: 'Kara',
            devamsizlik: 2,
            yoklama: false,
          },
          {
            no: '1004',
            isim: 'Fatma',
            soyisim: 'Kılıç',
            devamsizlik: 0,
            yoklama: false,
          },
          {
            no: '1003',
            isim: 'Ayşe',
            soyisim: 'Kara',
            devamsizlik: 2,
            yoklama: false,
          },
          {
            no: '1004',
            isim: 'Fatma',
            soyisim: 'Kılıç',
            devamsizlik: 0,
            yoklama: false,
          },
          {
            no: '1003',
            isim: 'Ayşe',
            soyisim: 'Kara',
            devamsizlik: 2,
            yoklama: false,
          },
          {
            no: '1004',
            isim: 'Fatma',
            soyisim: 'Kılıç',
            devamsizlik: 0,
            yoklama: false,
          },
          {
            no: '1003',
            isim: 'Ayşe',
            soyisim: 'Kara',
            devamsizlik: 2,
            yoklama: false,
          },
          {
            no: '1004',
            isim: 'Fatma',
            soyisim: 'Kılıç',
            devamsizlik: 0,
            yoklama: false,
          },
          {
            no: '1003',
            isim: 'Ayşe',
            soyisim: 'Kara',
            devamsizlik: 2,
            yoklama: false,
          },
          {
            no: '1004',
            isim: 'Fatma',
            soyisim: 'Kılıç',
            devamsizlik: 0,
            yoklama: false,
          },
        ],
      };
    },
    methods: {
      submit() {
        // yoklama verileri burada işlenir
        for (let i = 0; i < this.ogrenciler.length; i++) {
          const ogrenci = this.ogrenciler[i];
          if (!ogrenci.yoklama) {
            if (ogrenci.devamsizlik == 0){

            }
            
          }else{
            ogrenci.devamsizlik++;
          }
        }
        console.log(this.ogrenciler);
      },
    },
  };
  </script>
  
  <style>
  table {
    border-collapse: collapse;
    width: 100%;

  }
  form {
    margin-left:auto; 
    margin-right:auto;
  }
  
  th,
  td {
    border: 1px solid black;
    padding: 8px;
    text-align: left;
  }
  
  th {
    background-color: #dddddd;
  }
  
  button {
    margin-top: 10px;
    padding: 8px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s ease;
  }
  
  button:hover {
    background-color: #0062cc;
  }
  </style>
  