<template>
    <div class="register">
        <form @submit.prevent="register">
        <div class="form-control">
          <label for="name">Adınız:</label>
          <input type="text" id="name" v-model="name" required>
        </div>
        <div class="form-control">
          <label for="email">E-posta Adresi:</label>
          <input type="email" id="email" v-model="email" required>
        </div>
        <div class="form-control">
          <label for="password">Şifre:</label>
          <input type="password" id="password" v-model="password" required>
        </div>
        <div class="form-control">
          <label for="confirmPassword">Şifre Tekrarı:</label>
          <input type="password" id="confirmPassword" v-model="confirmPassword" required>
        </div>
        <button type="submit">Kaydol</button>
        <a href="/login">Giriş Yap</a>

      </form>

    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        name: '',
        email: '',
        password: '',
        confirmPassword: ''
      }
    },
    methods: {
      register() {
        // Kayıt işlemini gerçekleştir
        console.log('Kayıt işlemi gerçekleştirildi.')
      }
    }
  }
  </script>
  
  <style scoped>
  .register {
    margin-top: 100px;
    margin-left: 500px;
    max-width: 400px;
    padding: 20px;
    border-radius: 5px;
    background-color: #f9f9f9;
    box-shadow: 0 0 10px #ccc;
    
  }
  
  h2 {
    
    margin-bottom: 20px;
  }
  
  form {
    display: flex;
    flex-direction: column;
  }
  
  .form-control {
    margin-bottom: 10px;
  }
  
  label {
    
    font-weight: bold;
    margin-bottom: 5px;
  }
  
  input {
    padding: 10px;
    border-radius: 5px;
    border: none;
    float: right;
    box-shadow: 0 0 5px #ccc;
    font-size: 16px;
    
  }
  
  button[type="submit"] {
    padding: 10px;
    border-radius: 5px;
    border: none;
    background-color: #007bff;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.3s ease;
  }
  
  button[type="submit"]:hover {
    background-color: #555;
  }
  a {
    margin-top:10px;
    padding: 0.5rem;
    border-radius: 100px;
    border: none;
    background-color: #007bff;
    color: #fff;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    margin-left:auto;
    margin-right:auto;


  }
  
  a:hover {
    background-color: #0062cc;
  }
  </style>
  