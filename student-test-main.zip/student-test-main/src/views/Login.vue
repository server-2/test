<template>
    <div class="login-container">
      <form @submit.prevent="login">
        <label for="email">Email:</label>
        <input type="email" id="email" v-model="email" required>
        <label for="password">Password:</label>
        <input type="password" id="password" v-model="password" required>
        <button type="submit">Login</button>
        <a href="/register">Kayıt ol</a>

      </form>
      <p v-if="error" class="error">{{ error }}</p>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        email: '',
        password: '',
        error: '',
        current_email : 'mevlut@piple.co',
        current_password: '123123123'
      }
    },
    methods: {
      login() {
        // Burada gerekli işlemler yapılacak
        if(this.email === "mevlut@piple.co" && this.password=== "123123123"){
            this.$router.push('/student-list') // Başarılıysa yönlendirme yapılır
        }else{
            this.error = 'Email or password is incorrect' // Hata mesajı
        }
        console.log(`Email: ${this.email}, Password: ${this.password}`);
      }
    }
  }
  </script>
  
  <style scoped>
  .login-container {
    margin-top: 100px;
    margin-left: 500px;
    max-width: 400px;
    padding: 20px;
    border-radius: 5px;
    background-color: #f9f9f9;
    box-shadow: 0 0 10px #ccc;
    
  }

  
  form {
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }
  
  label {
    font-weight: bold;
  }
  
  input {
    padding: 0.5rem;
    border-radius: 5px;
    border: 1px solid #ccc;
  }
  
  button {
    padding: 0.5rem;
    border-radius: 5px;
    border: none;
    background-color: #007bff;
    color: #fff;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
  }
  
  button:hover {
    background-color: #0062cc;
  }
  a {
    margin-top:10px;
    padding: 0.5rem;
    border-radius: 100px;
    border: none;
    background-color: #007bff;
    color: #fff;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    margin-left:auto;
    margin-right:auto;


  }
  
  a:hover {
    background-color: #0062cc;
  }
  .error {
    color: red;
  }
  </style>
