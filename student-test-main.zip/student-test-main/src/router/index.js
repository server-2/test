import { createRouter, createWebHistory } from 'vue-router'
import Login from '../views/Login.vue'
import Register from '../views/Register.vue'
import HomePage from '../views/HomePage.vue'
import StudentList from '../views/StudentList.vue'
import YoklamaPage from '../views/YoklamaPage.vue'
import Ders from '../views/Ders.vue'
import OgrenciEkle from '../views/CreateStudent.vue'

const routes = [
  {
    path: '/',
    name: 'homepage',
    component: HomePage
  },
  {
    path: '/login',
    name: 'login',
    component: Login
  },
  {
    path: '/register',
    name: 'register',
    component: Register
  },
  {
    path: '/student-list',
    name: 'student-list',
    component: StudentList
  },
  {
    path: '/yoklama',
    name: 'yoklama',
    component: YoklamaPage
  },
  {
    path: '/dersler',
    name: 'dersler',
    component: Ders
  },
  {
    path: '/ogrenci-ekle',
    name: 'ogrenci-ekle',
    component: OgrenciEkle
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
