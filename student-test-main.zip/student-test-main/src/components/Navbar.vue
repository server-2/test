<template>
  <div class="nav">
    <div class="nav__item">
      <router-link to="/">Anasayfa</router-link>
    </div>
    <div class="nav__item">
      <router-link to="/login">Giriş Yap</router-link>
    </div>
    <div class="nav__item">
      <router-link to="/register">Kayıt Ol</router-link>
    </div>
    <div class="nav__item">
      <router-link to="/dersler">Ders Dökümanı</router-link>
    </div>
    <div class="nav__item">
      <router-link to="/yoklama">Yoklama</router-link>
    </div>
    <div class="nav__item">
      <router-link to="/student-list">Ogrenci Listesi</router-link>
    </div>
    <div class="nav__item">
      <router-link to="/ogrenci-ekle">Öğrenci Ekleme</router-link>
    </div>
  </div>
</template>

<script>
export default {
};
</script>

<style scoped>
.nav {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 60px;
  background-color: #f0f0f0;
}

.nav__item {
  margin: 0 10px;
  padding: 10px 20px;
  font-size: 16px;
  font-weight: bold;
  text-decoration: none;
  color: #333;
  border-radius: 5px;
  background-color: #eee;
  transition: all 0.3s ease;
}

.nav__item:hover {
  background-color: #ddd;
  color: #444;
}
</style>
